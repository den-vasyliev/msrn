$( function(){ $( "#pay_dialog" ).dialog( {autoOpen: false} ) } );
$( "#button" ).button();
$( "#radioset" ).buttonset();
$( "#tabs" ).tabs();
$( "#accordion" ).accordion({heightStyle: "content"}, {active: 2}, { collapsible: false });